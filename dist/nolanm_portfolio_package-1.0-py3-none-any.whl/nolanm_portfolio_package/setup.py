import subprocess


def main():
    subprocess.check_call(['pip', 'install', '-r', 'requirements.txt'])
